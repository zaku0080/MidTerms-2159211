var add;

var buttons = function() {
	mybuttons = document.getElementById("complete");
	apple = document.createElement('button');
}

function myFunction() {
	document.getElementsByName("tabInput").value = "";
}