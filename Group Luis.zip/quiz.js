function onSubmit(){
  var score = 0;
	var numOfQuestions = 15;


	var answerArr = ['b', 'a', 'd', 'b', 'e', 'c', 'a', 'b', 'c', 'd', 'a', 'c', 'b', 'd', 'c'];
  
  var question1 = document.forms['quiz']['question1'].value;
	var question2 = document.forms['quiz']['question2'].value;
	var question3 = document.forms['quiz']['question3'].value;
	var question4 = document.forms['quiz']['question4'].value;
	var question5 = document.forms['quiz']['question5'].value;

	var question6 = document.forms['quiz']['question6'].value;
	var question7 = document.forms['quiz']['question7'].value;
	var question8 = document.forms['quiz']['question8'].value;
	var question9 = document.forms['quiz']['question9'].value;
	var question10 = document.forms['quiz']['question10'].value;

	var question11 = document.forms['quiz']['question11'].value;
	var question12 = document.forms['quiz']['question12'].value;
	var question13 = document.forms['quiz']['question13'].value;
	var question14 = document.forms['quiz']['question14'].value;
	var question15 = document.forms['quiz']['question15'].value;

for (var i=1; i <= numOfQuestions; i++) {
		if(eval('question' + i) == answerArr[i - 1]){
			score ++;
		}
	}

document.getElementById("totalScore").innerHTML = score;
}



var parts = ["part1", "part2", "part3"];
var shownPart = null;s

function showParts(part) {
  if(shownPart === part) {
    //shownPart = null;
  } else {
    shownPart = part;
  }
  hideParts();
}

function hideParts() {
  var i, part, div;
  for(i = 0; i < parts.length; i++) {
    part = parts[i];
    div = document.getElementById(part);
    if(shownPart === part) {
      div.style.display = "block";
    } else {
      div.style.display = "none";
    }
  }
}