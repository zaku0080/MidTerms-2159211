1. Install xampp

2. Place the designated folder(index) into the xampp htdocs folder

3. Start/Open XAMPP and start Apache

4. Open a browser and type loaclhost/index/

*if an error occured and apache won't start it means that another program is using it. To
solve this problem, open task manager and "end task" the program using apache. There are
also times where you unit's firewall doesn't allow the ports used so turn off your firewall for
the time being